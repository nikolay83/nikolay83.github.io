- Deploy the "app" folder directory on local web-server.

-------
- ignore validation errors in "icons-sprites.css" (reusing existing CSS) & 
- error due to  @-webkit-keyframes (Fall-back vendor specific code)

------
- Scripts inside prod folder are generated minified code.
- Folder structure is same as in base mom_mobile app.

-------
on #/giftCardsDetails the following workflow takes to my card page:
- add to cart -> Login Now -> Enter any value of email & password -> Login.